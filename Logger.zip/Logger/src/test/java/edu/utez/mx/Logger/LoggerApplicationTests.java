package edu.utez.mx.Logger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
