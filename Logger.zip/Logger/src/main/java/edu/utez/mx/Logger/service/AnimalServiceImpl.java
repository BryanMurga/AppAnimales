package edu.utez.mx.Logger.service;

import edu.utez.mx.Logger.model.modelAnimales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class AnimalServiceImpl implements IAnimalService{
    @Autowired
    private IAnimal data;

    @Override
    public List<modelAnimales> getAllAnimales() {
        return (List<modelAnimales>) data.findAll();
    }

    @Override
    public Optional<modelAnimales> getAnimalById(int id) {
        return Optional.empty();
    }

    @Override
    public int saveAnimal(modelAnimales animales) {
        int response = 0;
        modelAnimales animal = data.save(animales);

        if (animal != null){
            response = 1;
        }

        return response;
    }

    @Override
    public void deleteAnimal(int id) {

    }
}
