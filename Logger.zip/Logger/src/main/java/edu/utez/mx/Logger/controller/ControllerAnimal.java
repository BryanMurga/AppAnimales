package edu.utez.mx.Logger.controller;

import edu.utez.mx.Logger.model.modelAnimales;
import edu.utez.mx.Logger.service.AnimalServiceImpl;
import edu.utez.mx.Logger.service.IAnimalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;
@Controller
@RequestMapping("/animal")
public class ControllerAnimal {
    @Autowired
    private AnimalServiceImpl service;

    @GetMapping("/")
    public String getAll(Model model){
        List<modelAnimales> list = service.getAllAnimales();
        model.addAttribute("animales", list);
        return "index";
    }

    @GetMapping("/form")
    public String moveForm(Model model){
        return "formulario";
    }

    @PostMapping("/save")
    public String saveAnimal ( modelAnimales animales, Model model) {
       // System.out.println(animales.toString());
        service.saveAnimal(animales);
        return "redirect:/animal/";
    }

}
